
CONTRIBUTING YOUR TRANSLATION


This plugin is ready for translation and has already been translated into several languages. But If your language is not available then you can make one. It is also possible that not all existing translations are up-to-date or correct, so you are welcome to make corrections. Many of plugin users would be delighted if you share your translation with the community. Thanks for your contribution!

If you want to help translate this plugin, please visit the [translation page](https://translate.wordpress.org/projects/wp-plugins/my-custom-functions). You can also use the POT file that is included and placed in the "languages" folder to create a translation PO file. Just send the PO file to us (https://www.spacexchimp.com/contact.html) and we will include this translation within the next plugin update.
